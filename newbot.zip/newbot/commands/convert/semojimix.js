const {sticker} = require('../../lib/convert')
const packInfo = { packname: config.packInfo.packname, author: config.packInfo.author };
module.exports = {
	name: "semojimix",
	cmd: ["semojimix"],
	ignored: true,
	async handler(m, { conn, text }) {
const stickerBuff = await sticker(await tool.getBuffer(text), { isImage: true, withPackInfo: true, packInfo})
await conn.sendMessage(m.from, { sticker: stickerBuff},{quoted: m})
}
}
